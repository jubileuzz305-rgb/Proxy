package com.example.ffproxy;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import android.text.InputType;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private EditText hostInput, portInput;
    private Spinner typeSpinner;
    private TextView status, result;
    private Button testButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16,9,28));
        getWindow().setNavigationBarColor(Color.rgb(16,9,28));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(20));
        root.setBackgroundColor(Color.rgb(16,9,28));

        TextView title = new TextView(this);
        title.setText("FF PROXY");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Teste de conexão com um servidor proxy");
        subtitle.setTextColor(Color.rgb(190,170,210));
        subtitle.setTextSize(14);
        LinearLayout.LayoutParams subP = params();
        subP.bottomMargin = dp(22);
        root.addView(subtitle, subP);

        addLabel(root, "ENDEREÇO DO PROXY");
        hostInput = new EditText(this);
        hostInput.setSingleLine(true);
        hostInput.setHint("Ex.: 192.168.1.10");
        hostInput.setTextColor(Color.WHITE);
        hostInput.setHintTextColor(Color.GRAY);
        hostInput.setInputType(InputType.TYPE_CLASS_TEXT);
        styleInput(hostInput);
        root.addView(hostInput, params());

        addLabel(root, "PORTA");
        portInput = new EditText(this);
        portInput.setSingleLine(true);
        portInput.setHint("Ex.: 8080");
        portInput.setText("8080");
        portInput.setTextColor(Color.WHITE);
        portInput.setHintTextColor(Color.GRAY);
        portInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        styleInput(portInput);
        root.addView(portInput, params());

        addLabel(root, "TIPO DE PROXY");
        typeSpinner = new Spinner(this);
        String[] types = {"HTTP (CONNECT)", "SOCKS5"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
            android.R.layout.simple_spinner_dropdown_item, types);
        typeSpinner.setAdapter(adapter);
        root.addView(typeSpinner, params());

        testButton = new Button(this);
        testButton.setText("TESTAR PROXY");
        testButton.setTextColor(Color.WHITE);
        testButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(126,34,206)));
        LinearLayout.LayoutParams bp = params();
        bp.topMargin = dp(22);
        root.addView(testButton, bp);

        status = new TextView(this);
        status.setText("● Aguardando teste");
        status.setTextColor(Color.rgb(196,181,253));
        status.setTextSize(16);
        LinearLayout.LayoutParams sp = params();
        sp.topMargin = dp(18);
        root.addView(status, sp);

        result = new TextView(this);
        result.setText("Informe o endereço e a porta de um proxy que você tenha autorização para usar.");
        result.setTextColor(Color.LTGRAY);
        result.setTextSize(14);
        LinearLayout.LayoutParams rp = params();
        rp.topMargin = dp(8);
        root.addView(result, rp);

        TextView note = new TextView(this);
        note.setText("\nImportante: este app apenas testa o proxy. Ele não cria um servidor proxy nem altera a mira, o registro de tiros ou o funcionamento do Free Fire. Um proxy válido precisa estar hospedado e ativo.");
        note.setTextColor(Color.rgb(160,145,175));
        note.setTextSize(12);
        LinearLayout.LayoutParams np = params();
        np.topMargin = dp(18);
        root.addView(note, np);

        testButton.setOnClickListener(v -> runTest());
        setContentView(root);
    }

    private void runTest() {
        final String host = hostInput.getText().toString().trim();
        final String portText = portInput.getText().toString().trim();
        if (host.isEmpty() || portText.isEmpty()) {
            status.setText("● Preencha endereço e porta");
            return;
        }
        final int port;
        try {
            port = Integer.parseInt(portText);
            if (port < 1 || port > 65535) throw new NumberFormatException();
        } catch (Exception e) {
            status.setText("● Porta inválida");
            return;
        }

        testButton.setEnabled(false);
        status.setText("● Testando...");
        result.setText("Conectando ao proxy e verificando um túnel seguro para 1.1.1.1:443.");

        new Thread(() -> {
            long start = System.nanoTime();
            String message;
            boolean ok = false;
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(host, port), 5000);
                socket.setSoTimeout(5000);
                if (typeSpinner.getSelectedItemPosition() == 0) {
                    OutputStream out = socket.getOutputStream();
                    InputStream in = socket.getInputStream();
                    String request = "CONNECT 1.1.1.1:443 HTTP/1.1\r\nHost: 1.1.1.1:443\r\nProxy-Connection: Keep-Alive\r\n\r\n";
                    out.write(request.getBytes(StandardCharsets.US_ASCII));
                    out.flush();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.US_ASCII));
                    String line = reader.readLine();
                    if (line != null && (line.contains("200") || line.contains("Connection established"))) {
                        ok = true;
                        message = "Túnel HTTP CONNECT aceito.\nResposta: " + line;
                    } else {
                        message = "O proxy respondeu, mas não aceitou o túnel.\nResposta: " + (line == null ? "sem resposta" : line);
                    }
                } else {
                    InputStream in = socket.getInputStream();
                    OutputStream out = socket.getOutputStream();
                    out.write(new byte[]{0x05, 0x01, 0x00});
                    out.flush();
                    int v = in.read(), method = in.read();
                    if (v == 0x05 && method == 0x00) {
                        out.write(new byte[]{0x05, 0x01, 0x00, 0x01, 1, 1, 1, 1, 0x01, (byte)0xBB});
                        out.flush();
                        byte[] reply = new byte[10];
                        int count = 0;
                        while (count < reply.length) {
                            int n = in.read(reply, count, reply.length-count);
                            if (n < 0) break;
                            count += n;
                        }
                        if (count >= 2 && reply[1] == 0x00) {
                            ok = true;
                            message = "Conexão SOCKS5 estabelecida com 1.1.1.1:443.";
                        } else {
                            message = "SOCKS5 respondeu, mas não abriu o túnel (código " +
                                (count >= 2 ? (reply[1] & 255) : -1) + ").";
                        }
                    } else {
                        message = "O servidor não aceitou SOCKS5 sem autenticação.";
                    }
                }
            } catch (Exception e) {
                message = "Falha no teste: " + e.getClass().getSimpleName() + " — " +
                    (e.getMessage() == null ? "sem detalhes" : e.getMessage());
            }
            final long ms = (System.nanoTime() - start) / 1_000_000L;
            final boolean success = ok;
            final String finalMessage = message;
            runOnUiThread(() -> {
                status.setText(success ? "● Proxy respondeu" : "● Teste não concluído");
                status.setTextColor(success ? Color.rgb(74,222,128) : Color.rgb(248,113,113));
                result.setText(finalMessage + "\n\nTempo total do teste: " + ms + " ms");
                testButton.setEnabled(true);
            });
        }).start();
    }

    private void addLabel(LinearLayout root, String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(Color.rgb(196,181,253));
        label.setTextSize(11);
        label.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams p = params();
        p.topMargin = dp(13);
        p.bottomMargin = dp(4);
        root.addView(label, p);
    }

    private void styleInput(EditText e) {
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(168,85,247)));
    }

    private LinearLayout.LayoutParams params() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
